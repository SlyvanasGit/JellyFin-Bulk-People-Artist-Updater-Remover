(function () {
    function initPage() {
        if (document.getElementById("bulk-actor-tool")) return;
        const mc = document.querySelector(".content-primary") || document.querySelector("#dashboardPage");
        if (!mc) return;

        const c = document.createElement("div");
        c.id = "bulk-actor-tool";
        c.style.cssText = "background:#1c1c1c;padding:25px;margin:20px 0;border:2px solid #00a4dc;border-radius:8px;color:#fff;font-family:sans-serif;";
        c.innerHTML = `
            <h2 style="color:#00a4dc;margin-top:0;">Bulk People/Artist Updater & Remover</h2>
            <p style="color:#bbb;font-size:14px;">Select a library type, choose your item, pick the target episodes/tracks, and Add or Remove your People/Artists.</p>
            
            <div style="margin: 15px 0; display:flex; gap:20px; flex-wrap:wrap; background:#222; padding:10px; border-radius:4px;">
                <label style="font-weight:bold;">1. Select Library Type:</label>
                <label><input type="radio" name="bType" value="Series" checked /> TV Shows</label>
                <label><input type="radio" name="bType" value="Movie" /> Movies</label>
                <label><input type="radio" name="bType" value="MusicVideo" /> Music Videos</label>
                <label><input type="radio" name="bType" value="BoxSet" /> Collections</label>
            </div>

            <div style="margin: 15px 0;">
                <label id="bSelectLabel" style="display:block; margin-bottom:5px; font-weight:bold;">2. Select TV Series:</label>
                <select id="bSeries" style="width:100%;padding:10px;background:#2b2b2b;color:#fff;border:1px solid #444;border-radius:4px;"></select>
            </div>
            
            <div id="bEpSection" style="display:none; margin-top:15px;">
                <label id="bListLabel" style="display:block; margin-bottom:5px; font-weight:bold;">3. Select Target Episodes:</label>
                <button type="button" id="bToggleAll" style="background:#444; color:#fff; border:none; padding:6px 12px; margin-bottom:10px; cursor:pointer; border-radius:4px;">Select / Deselect All</button>
                <div id="bEpList" style="max-height:200px;overflow-y:auto;border:1px solid #444;padding:10px;margin-bottom:15px;background:#111;border-radius:4px;"></div>
                
                <div style="margin-bottom:12px;">
                    <label style="display:block; margin-bottom:5px; font-weight:bold;">4. Person / Artist Name:</label>
                    <input type="text" id="bActor" style="width:100%;padding:10px;background:#2b2b2b;color:#fff;border:1px solid #444;border-radius:4px;" placeholder="e.g., Bryan Cranston or Linkin Park" />
                </div>
                
                <div id="bRoleContainer" style="margin-bottom:20px;">
                    <label style="display:block; margin-bottom:5px; font-weight:bold;">5. Role / Character Name (Adding only):</label>
                    <input type="text" id="bRole" style="width:100%;padding:10px;background:#2b2b2b;color:#fff;border:1px solid #444;border-radius:4px;" placeholder="e.g., Walter White (Optional)" />
                </div>
                
                <div style="display:flex; gap:15px;">
                    <button type="button" id="bSubmit" style="flex:1;padding:12px;background:#00a4dc;color:#fff;border:none;font-weight:bold;font-size:16px;border-radius:4px;cursor:pointer;">Add Entry</button>
                    <button type="button" id="bDelete" style="flex:1;padding:12px;background:#cc3333;color:#fff;border:none;font-weight:bold;font-size:16px;border-radius:4px;cursor:pointer;">Delete Entry</button>
                </div>
            </div>
        `;

        mc.insertBefore(c, mc.firstChild);

        const ss = document.getElementById("bSeries");
        const es = document.getElementById("bEpSection");
        const el = document.getElementById("bEpList");
        const selectLabel = document.getElementById("bSelectLabel");
        const listLabel = document.getElementById("bListLabel");
        const roleContainer = document.getElementById("bRoleContainer");

        function loadDropdown() {
            const selectedType = document.querySelector('input[name="bType"]:checked').value;
            es.style.display = "none";
            ss.innerHTML = '<option value="">Loading...</option>';

            if (selectedType === "Series") {
                selectLabel.innerText = "2. Select TV Series:";
                listLabel.innerText = "3. Select Target Episodes:";
                roleContainer.style.display = "block";
            } else if (selectedType === "Movie") {
                selectLabel.innerText = "2. Select Movie:";
                listLabel.innerText = "3. Confirm Selection:";
                roleContainer.style.display = "block";
            } else if (selectedType === "MusicVideo") {
                selectLabel.innerText = "2. Select Music Video:";
                listLabel.innerText = "3. Confirm Selection:";
                roleContainer.style.display = "none";
            } else if (selectedType === "BoxSet") {
                selectLabel.innerText = "2. Select Collection:";
                listLabel.innerText = "3. Confirm Selection:";
                roleContainer.style.display = "block";
            }

            ApiClient.getJSON(ApiClient.getUrl("Items", { IncludeItemTypes: selectedType, Recursive: true })).then(function (res) {
                ss.innerHTML = '<option value="">Choose an item...</option>';
                res.Items.sort((a, b) => a.Name.localeCompare(b.Name)).forEach(item => {
                    ss.innerHTML += `<option value="${item.Id}">${item.Name}</option>`;
                });
            });
        }

        document.querySelectorAll('input[name="bType"]').forEach(radio => {
            radio.addEventListener('change', loadDropdown);
        });

        loadDropdown();

        ss.addEventListener("change", function () {
            if (!this.value) { es.style.display = "none"; return; }
            const selectedType = document.querySelector('input[name="bType"]:checked').value;

            if (selectedType === "Series") {
                ApiClient.getJSON(ApiClient.getUrl("Items", { ParentId: this.value, IncludeItemTypes: "Episode", Recursive: true })).then(function (res) {
                    el.innerHTML = "";
                    res.Items.sort((a, b) => (a.ParentIndexNumber || 0) - (b.ParentIndexNumber || 0) || (a.IndexNumber || 0) - (b.IndexNumber || 0)).forEach(e => {
                        const sNum = e.ParentIndexNumber || 1;
                        const eNum = e.IndexNumber || 1;
                        el.innerHTML += `<label style="display:block;margin:6px 0;cursor:pointer;"><input type="checkbox" class="b-chk" value="${e.Id}" style="margin-right:8px;" /> S${sNum}:E${eNum} - ${e.Name}</label>`;
                    });
                    es.style.display = "block";
                });
            } else {
                const itemName = ss.options[ss.selectedIndex].text;
                el.innerHTML = `<label style="display:block;margin:6px 0;cursor:pointer;"><input type="checkbox" class="b-chk" value="${this.value}" checked style="margin-right:8px;" /> ${itemName}</label>`;
                es.style.display = "block";
            }
        });

        document.getElementById("bToggleAll").addEventListener("click", function () {
            const chks = document.querySelectorAll(".b-chk");
            const ts = !Array.from(chks).every(c => c.checked);
            chks.forEach(c => c.checked = ts);
        });

        document.getElementById("bSubmit").addEventListener("click", function () {
            const chks = document.querySelectorAll(".b-chk:checked");
            const actor = document.getElementById("bActor").value.trim();
            const role = document.getElementById("bRole").value.trim() || "Actor";
            const selectedType = document.querySelector('input[name="bType"]:checked').value;
            const personType = (selectedType === "MusicVideo") ? "Artist" : "Actor";

            if (!actor) { alert("Please enter a Name."); return; }
            if (chks.length === 0) { alert("Please select at least one item."); return; }

            let done = 0;
            chks.forEach(cb => {
                ApiClient.getItem(ApiClient.getCurrentUserId(), cb.value).then(function (item) {
                    if (!item.People) item.People = [];
                    if (!item.People.some(p => p.Name.toLowerCase() === actor.toLowerCase())) {
                        item.People.push({ Name: actor, Role: role, Type: personType });
                        ApiClient.updateItem(item).then(() => {
                            done++;
                            if (done === chks.length) alert("Successfully added entry!");
                        });
                    } else {
                        done++;
                        if (done === chks.length) alert("Finished! (Skipped existing entries)");
                    }
                });
            });
        });

        document.getElementById("bDelete").addEventListener("click", function () {
            const chks = document.querySelectorAll(".b-chk:checked");
            const actor = document.getElementById("bActor").value.trim();
            if (!actor || chks.length === 0) { alert("Make sure name is typed and items checked."); return; }
            if (!confirm(`Completely remove "${actor}" from checked items?`)) return;

            let done = 0;
            chks.forEach(cb => {
                ApiClient.getItem(ApiClient.getCurrentUserId(), cb.value).then(function (item) {
                    if (item.People) {
                        const ol = item.People.length;
                        item.People = item.People.filter(p => p.Name.toLowerCase() !== actor.toLowerCase());
                        if (item.People.length !== ol) {
                            ApiClient.updateItem(item).then(() => {
                                done++;
                                if (done === chks.length) alert("Successfully removed entries!");
                            });
                        } else {
                            done++;
                            if (done === chks.length) alert("Finished configuration changes!");
                        }
                    } else {
                        done++;
                        if (done === chks.length) alert("Finished configuration changes!");
                    }
                });
            });
        });
    }

    document.addEventListener("viewshow", function (e) {
        if (e.detail.type === "dashboard" || window.location.href.includes("dashboard")) {
            setTimeout(initPage, 500);
        }
    });
})();